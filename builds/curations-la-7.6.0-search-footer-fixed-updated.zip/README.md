# ghost-7
Complete theme for Ghost
